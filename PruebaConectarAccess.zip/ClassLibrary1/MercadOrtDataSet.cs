﻿namespace ClassLibrary1
{


    partial class MercadOrtDataSet
    {
    }
}

namespace ClassLibrary1.MercadOrtDataSetTableAdapters {
    
    
    public partial class UsuarioTableAdapter {
    }
}
